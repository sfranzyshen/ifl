#!/bin/bash

sudo cp 69-USB-encoder.rules /etc/udev/rules.d/69-USB-Encoder.rules
mv ~/.config/Vrui-8.0/Applications/SARndbox.cfg ~/.config/Vrui-8.0/Applications/SARndbox.bak
cp SARndbox.cfg ~/.config/Vrui-8.0/Applications/SARndbox.cfg
