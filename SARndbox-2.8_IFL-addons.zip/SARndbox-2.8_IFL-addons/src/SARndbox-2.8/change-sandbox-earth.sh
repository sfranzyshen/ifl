#!/bin/bash
# use the water shader file

echo "colorMap HeightColorMap.cpt" >share/SARndbox-2.8/Control.fifo


