1) download archive
2) extract
3) cd to Encoder folder
4) $> bash fixup-sandbox.sh