#!/bin/bash

sudo cp 69-USB-encoder.rules /etc/udev/rules.d/69-USB-Encoder.rules

